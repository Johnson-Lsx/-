#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<fstream>
#include<cstring>
using namespace std;

const int MAX = 20;
int NT[MAX];
int vis[MAX];
int numF[MAX];
int numL[MAX];
char relation[MAX][MAX];

class production
{
public:
	char* left;
	char** right;
	int rows;
	production()
	{
		left = new char[MAX];
		right = new char* [MAX];
		for (int i = 0; i < MAX; ++i)
		{
			right[i] = new char[MAX];
		}
		rows = 0;
	}
	production(char* l, char** r, int row)
	{
		rows = row;
		strcpy(left, l);
		right = new char* [row];
		for (int i = 0; i < row; ++i)
		{
			strcpy(right[i], r[i]);
		}
	}
	void print()
	{
		printf("%s -> %s", left, right[0]);
		for (int i = 1; i < rows; ++i)
		{
			printf(" | %s", right[i]);
		}
		cout << endl;
	}
};

int getInput(char** buffer)
{
	int numOfrows = 0;
	ifstream in("test.txt");
	if (!in.is_open())
	{
		cout << "Error opening file"; exit(1);
	}
	while (!in.eof() && numOfrows < MAX)
	{
		in.getline(buffer[numOfrows], 100);
		numOfrows++;
	}
	if (numOfrows == MAX)
	{
		cout << "There are too many productions! Pleas set MAX larger!" << endl;
		exit(-1);
	}
	return numOfrows;
}

void getProductions(char** buffer, production* prod, const int& cnt)
{
	//cnt表示总共有几行产生式
	int temp = 0;
	for (int i = 0; i < cnt; ++i)
	{
		int len = strlen(buffer[i]);
		//len表示每条产生式的长度
		int idx = 0;
		//idx表示"->"中"-"所在位置
		int numOfright = 0;
		//numOfright表示一个非终结符号对应的产生式个数
		int* idx1 = new int[MAX];
		//idx1记录了产生式右部"|"的位置
		int tmp = 0;
		//tmp记录产生式右部"|"的个数
		for (int j = 0; j < len - 1; ++j)
		{
			if (buffer[i][j] == '-' && buffer[i][j + 1] == '>')
			{
				idx = j;
				break;
			}
		}
		if (idx == 0)//"->"不应该出现在产生式最左边
		{
			cout << "The production is wrong!" << endl;
			exit(-1);
		}
		for (int k = 0; k < idx; ++k)
		{
			if (k != idx - 1)
				prod[i].left[k] = buffer[i][k];
			else
				prod[i].left[k] = '\0';//buffer[i][idx-1]是空格
		}
		idx1[0] = idx + 1;
		for (int k = idx + 2; k < len; ++k)
		{
			if (buffer[i][k] == '|')
			{
				idx1[tmp + 1] = k;
				tmp++;
			}
		}
		idx1[tmp + 1] = len + 1;
		prod[i].rows = tmp + 1;
		for (int k = 0; k < tmp + 1; ++k)
		{
			int start = idx1[k] + 2;
			int end = idx1[k + 1];
			for (int m = start; m < end; ++m)
			{
				if (m != end - 1)
					prod[i].right[k][m - start] = buffer[i][m];
				else
					prod[i].right[k][m - start] = '\0';
			}
		}
	}
}

void getVN(char** VN, production* prod, const int& cnt)
{
	for (int i = 0; i < cnt; ++i)
	{
		strcpy(VN[i], prod[i].left);
	}
}

int getVT(char** VT, char** VN, production* prod, const int& cnt, char*** table)
{
	int index = 0;                //计数终结符的个数
	for (int i = 0; i < cnt; ++i) //对每个产生式
	{
		int numOfToken = 0;
		for (int j = 0; j < prod[i].rows; ++j) //对每个产生式的所有右部
		{
			//char id = char(j + '0');
			table[i][numOfToken][0] = char(j + '0');
			table[i][numOfToken][1] = '\0';
			numOfToken++;
			int len = strlen(prod[i].right[j]);
			int m = 0;
			char* tmp = new char[MAX];
			for (int k = 0; k < len; ++k)
			{
				if (prod[i].right[j][k] != ' ')
				{
					tmp[m] = prod[i].right[j][k];
					m++;
					if (k == len - 1)
					{
						tmp[m] = '\0'; //说明得到了一个文法符号串
						m = 0;         //将m清零便于下一个文法符号的获取
						strcpy(table[i][numOfToken], tmp);
						numOfToken++;
						//下面判断获取到的是否属于非终结符
						bool flag = false;
						for (int w = 0; w < cnt; ++w)
						{
							if (strcmp(tmp, VN[w]) == 0)
							{
								flag = true;
								break;
							}
						}
						if (!flag)
						{
							bool flag1 = true;
							for (int kk = 0; kk < index; ++kk)
							{
								if (strcmp(VT[kk], tmp) == 0)
								{
									flag1 = false;
									break;
								}
							}
							if (flag1)
							{
								strcpy(VT[index], tmp);
								index++;
							}
						}
					}
				}
				else
				{
					tmp[m] = '\0'; //说明得到了一个文法符号串
					m = 0;         //将m清零便于下一个文法符号的获取
					strcpy(table[i][numOfToken], tmp);
					numOfToken++;
					//下面判断获取到的是否属于非终结符
					bool flag = false;
					for (int w = 0; w < cnt; ++w)
					{
						if (strcmp(tmp, VN[w]) == 0)
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						bool flag1 = true;
						for (int kk = 0; kk < index; ++kk)
						{
							if (strcmp(VT[kk], tmp) == 0)
							{
								flag1 = false;
								break;
							}
						}
						if (flag1)
						{
							strcpy(VT[index], tmp);
							index++;
						}
					}
				}
			}
		}
		NT[i] = numOfToken;
	}
	return index;
}

bool isVT(char* s, char** VT, int cnt1)
{
	bool flag = false;
	for (int i = 0; i < cnt1; ++i)
	{
		if (strcmp(s, VT[i]) == 0)
		{
			flag = true;
			break;
		}
	}
	return flag;
}

bool check(production* prod, const int& cnt, char** VT, int cnt1)
{
	bool flag = true;
	int len = 0;
	int idx = 0;
	int index = 0;
	char* epsilon = new char[2];
	char* tmp = new char[MAX];
	char* rtmp = new char[MAX];
	epsilon[0] = '#';
	epsilon[1] = '\0';
	for (int i = 0; i < cnt; ++i)
	{
		for (int j = 0; j < prod[i].rows; ++j)
		{
			//产生式里面有空串
			if (strcmp(prod[i].right[j], epsilon) == 0)
			{
				flag = false;
				return flag;
			}
			char** tokens = new char* [MAX];
			for (int i = 0; i < MAX; ++i)
			{
				tokens[i] = new char[MAX];
			}
			strcpy(rtmp, prod[i].right[j]);
			len = strlen(rtmp);
			idx = 0;
			index = 0;
			for (int k = 0; k < len; ++k)
			{
				if (rtmp[k] == ' ' || k == len - 1)
				{
					if (k == len - 1)
					{
						tmp[idx] = rtmp[k];
						idx++;
					}
					tmp[idx] = '\0';
					strcpy(tokens[index], tmp);
					index++;
					idx = 0;
					strcpy(tmp, "");
				}
				else
				{
					tmp[idx] = rtmp[k];
					idx++;
				}
			}
			for (int k = 0; k < index - 1; ++k)
			{
				if (!isVT(tokens[k], VT, cnt1) && !isVT(tokens[k + 1], VT, cnt1))
				{
					flag = false;
					return flag;
				}
			}
		}
	}
	return flag;
}

int DFS(int x, production* prod, char** VT, int cnt, int cnt1, char*** FIRSTVT, char*** SET)
{
	if (vis[x])
		return numF[x];
	vis[x] = 1;
	int num = 0;
	int idx = 0;
	for (int i = 0; i < prod[x].rows; ++i)//对第x个非终结符的每个产生式右部
	{
		int nt = 0;
		char* number1 = new char[MAX];
		char* number2 = new char[MAX];
		char** tmp = new char* [MAX];
		number1[0] = char(i + '0');
		number1[1] = '\0';
		number2[0] = char(i + 1 + '0');
		number2[1] = '\0';
		for (int j = 0; j < MAX; ++j)
		{
			tmp[j] = new char[MAX];
		}
		for (int j = idx; j < NT[x]; ++j)
		{
			if (strcmp(SET[x][j], number1) == 0)
				continue;
			if (strcmp(SET[x][j], number2) == 0)
			{
				idx = j;
				break;
			}
			strcpy(tmp[nt], SET[x][j]);
			nt++;
		}
		if (nt == 0)
		{
			cout << "error!";
			exit(-1);
		}
		if (isVT(tmp[0], VT, cnt1))//P -> a....
		{
			strcpy(FIRSTVT[x][num], tmp[0]);
			num++;
		}
		else //第一个符号不是终结符
		{
			if (nt > 1 && isVT(tmp[1], VT, cnt1)) //P -> Qa...
			{
				strcpy(FIRSTVT[x][num], tmp[1]);
				num++;
			}
			int y = 0;
			for (int k = 0; k < cnt; ++k)
			{
				if (strcmp(tmp[0], prod[k].left) == 0)
				{
					y = k;
					break;
				}
			}
			if (y != x)
			{
				int numy = DFS(y, prod, VT, cnt, cnt1, FIRSTVT, SET);
				for (int k = 0; k < numy; ++k)
				{
					bool flag = true;
					for (int kk = 0; kk < num; ++kk)
					{
						if (strcmp(FIRSTVT[x][kk], FIRSTVT[y][k]) == 0)
						{
							flag = false;
							break;
						}
					}
					if (flag)
					{
						strcpy(FIRSTVT[x][num], FIRSTVT[y][k]);
						num++;
					}
				}
			}
		}
	}
	numF[x] = num;
	return num;
}

int DFS1(int x, production* prod, char** VT, int cnt, int cnt1, char*** LASTVT, char*** SET)
{
	if (vis[x])
		return numL[x];
	vis[x] = 1;
	int num = 0;
	int idx = 0;
	for (int i = 0; i < prod[x].rows; ++i)//对第x个非终结符的每个产生式右部
	{
		int nt = 0;
		char* number1 = new char[MAX];
		char* number2 = new char[MAX];
		char** tmp = new char* [MAX];
		number1[0] = char(i + '0');
		number1[1] = '\0';
		number2[0] = char(i + 1 + '0');
		number2[1] = '\0';
		for (int j = 0; j < MAX; ++j)
		{
			tmp[j] = new char[MAX];
		}
		for (int j = idx; j < NT[x]; ++j)
		{
			if (strcmp(SET[x][j], number1) == 0)
				continue;
			if (strcmp(SET[x][j], number2) == 0)
			{
				idx = j;
				break;
			}
			strcpy(tmp[nt], SET[x][j]);
			nt++;
		}
		if (nt == 0)
		{
			cout << "error!";
			exit(-1);
		}
		int L = nt - 1;
		if (isVT(tmp[L], VT, cnt1))//P -> ...a
		{
			strcpy(LASTVT[x][num], tmp[L]);
			num++;
		}
		else //最后一个符号不是终结符
		{
			if (nt > 1 && isVT(tmp[L - 1], VT, cnt1)) //P -> ...aQ
			{
				strcpy(LASTVT[x][num], tmp[L - 1]);
				num++;
			}
			int y = 0;
			for (int k = 0; k < cnt; ++k)
			{
				if (strcmp(tmp[L], prod[k].left) == 0)
				{
					y = k;
					break;
				}
			}
			if (y != x)
			{
				int numy = DFS1(y, prod, VT, cnt, cnt1, LASTVT, SET);
				for (int k = 0; k < numy; ++k)
				{
					bool flag = true;
					for (int kk = 0; kk < num; ++kk)
					{
						if (strcmp(LASTVT[x][kk], LASTVT[y][k]) == 0)
						{
							flag = false;
							break;
						}
					}
					if (flag)
					{
						strcpy(LASTVT[x][num], LASTVT[y][k]);
						num++;
					}
				}
			}
		}
	}
	numL[x] = num;
	return num;
}

void make_first(production* prod, char** VT, int cnt, int cnt1, char*** FIRSTVT, char*** SET)
{
	memset(vis, 0, sizeof(vis));
	for (int i = 0; i < cnt; i++)
		if (vis[i]) continue;
		else DFS(i, prod, VT, cnt, cnt1, FIRSTVT, SET);
}

void make_last(production* prod, char** VT, int cnt, int cnt1, char*** LASTVT, char*** SET)
{
	memset(vis, 0, sizeof(vis));
	for (int i = 0; i < cnt; i++)
		if (vis[i]) continue;
		else DFS1(i, prod, VT, cnt, cnt1, LASTVT, SET);
}

int VTID(char** VT, char* s, int cnt1)
{
	int id = -1;
	for (int i = 0; i < cnt1; ++i)
	{
		if (strcmp(VT[i], s) == 0)
		{
			id = i;
			break;
		}
	}
	return id;
}

int VNID(char** VN, char* s, int cnt)
{
	int id = -1;
	for (int i = 0; i < cnt; ++i)
	{
		if (strcmp(VN[i], s) == 0)
		{
			id = i;
			break;
		}
	}
	return id;
}

void make_table(production* prod, int cnt, int cnt1, char*** SET, char** VT, char** VN, char*** FIRSTVT, char*** LASTVT)
{
	for (int i = 0; i < MAX; i++)
		for (int j = 0; j < MAX; j++)
			relation[i][j] = ' ';

	for (int i = 0; i < cnt; ++i) //对每个非终结符
	{
		int idx = 0;
		for (int j = 0; j < prod[i].rows; ++j) //对每个产生式右部
		{
			int nt = 0;
			char* number1 = new char[MAX];
			char* number2 = new char[MAX];
			char** tmp = new char* [MAX];
			number1[0] = char(j + '0');
			number1[1] = '\0';
			number2[0] = char(j + 1 + '0');
			number2[1] = '\0';
			for (int k = 0; k < MAX; ++k)
			{
				tmp[k] = new char[MAX];
			}
			for (int k = idx; k < NT[i]; ++k)
			{
				if (strcmp(SET[i][k], number1) == 0)
					continue;
				if (strcmp(SET[i][k], number2) == 0)
				{
					idx = k;
					break;
				}
				strcpy(tmp[nt], SET[i][k]);
				nt++;
			}
			if (nt == 0)
			{
				cout << "error!";
				exit(-1);
			}
			//tmp就是某一产生式的右部,长度nt
			for (int k = 0; k <= nt - 1; ++k)
			{
				if (isVT(tmp[k], VT, cnt1) && isVT(tmp[k + 1], VT, cnt1)) //两个相邻的终结符号
				{
					relation[VTID(VT, tmp[k], cnt1)][VTID(VT, tmp[k + 1], cnt1)] = '=';
				}
				if (!isVT(tmp[k], VT, cnt1) && isVT(tmp[k + 1], VT, cnt1)) //非终结符号后面跟着终结符号
				{
					int vn = VNID(VN, tmp[k], cnt);
					for (int v = 0; v < numL[vn]; ++v)
					{
						relation[VTID(VT, LASTVT[vn][v], cnt1)][VTID(VT, tmp[k + 1], cnt1)] = '>';
					}
				}
				if (isVT(tmp[k], VT, cnt1) && !isVT(tmp[k + 1], VT, cnt1)) //终结符号后面跟着非终结符号
				{
					int vn = VNID(VN, tmp[k + 1], cnt);
					for (int v = 0; v < numF[vn]; ++v)
					{
						relation[VTID(VT, tmp[k], cnt1)][VTID(VT, FIRSTVT[vn][v], cnt1)] = '<';
					}
				}
				if (k > nt - 2)
					continue;
				if (isVT(tmp[k], VT, cnt1) && !isVT(tmp[k + 1], VT, cnt1) && isVT(tmp[k + 2], VT, cnt1))
				{
					relation[VTID(VT, tmp[k], cnt1)][VTID(VT, tmp[k + 2], cnt1)] = '=';
				}
			}
		}
	}
	for (int v = 0; v < numF[0]; ++v)
	{
		relation[cnt1][VTID(VT, FIRSTVT[0][v], cnt1)] = '<';
	}
	for (int v = 0; v < numL[0]; ++v)
	{
		relation[VTID(VT, LASTVT[0][v], cnt1)][cnt1] = '>';
	}
	relation[cnt1][cnt1] = '=';
}

void print_table(char** VT, int cnt1)
{
    cout << "**********Operator First Analysis Table**********" << endl;
    for (int i = 0; i < (cnt1 + 2) * 5; i++)
		printf("-");
	for (int i = 0; i < (cnt1 + 2) * 5; i++)
		printf("-");
	puts("");
	printf("|%8s|", "");
	for (int i = 0; i < cnt1; i++)
		printf("%5s%5s", VT[i], "|");
	printf("%5s%5s", "$", "|");
	puts("");
	for (int i = 0; i < (cnt1 + 2) * 10; i++)
		printf("-");
	puts("");
	for (int i = 0; i < cnt1 + 1; i++)
	{
		if (i != cnt1)
		{
			printf("|%4s%5s", VT[i], "|");
		}
		else
		{
			printf("|%4s%5s", "$", "|");
		}
		for (int j = 0; j < cnt1 + 1; j++)
		{
			if (j != cnt1 && i != cnt1)
				printf("%5c%5s", relation[VTID(VT, VT[i], cnt1)][VTID(VT, VT[j], cnt1)], "|");
			else
			{
				if (j == cnt1 && i != cnt1)
				{
					printf("%5c%5s", relation[VTID(VT, VT[i], cnt1)][cnt1], "|");
				}
				else
				{
					if (i == cnt1 && j != cnt1)
						printf("%5c%5s", relation[cnt1][VTID(VT, VT[j], cnt1)], "|");
					else
						printf("%5c%5s", relation[cnt1][cnt1], "|");
				}
			}

		}
		puts("");
		for (int i = 0; i < (cnt1 + 2) * 10; i++)
			printf("-");
		puts("");
	}
}

void printinfo(int& cnt, int& cnt1, production* prod, char** VN, char** VT, char*** FIRSTVT, char*** LASTVT)
{
	cout << "**********Productions**********" << endl;
	for (int i = 0; i < cnt; ++i)
	{
		prod[i].print();
	}
	cout << "**********VN**********" << endl;
	for (int i = 0; i < cnt; ++i)
	{
		cout << VN[i] << " ";
	}
	cout << endl;
	cout << "**********VT**********" << endl;
	for (int i = 0; i < cnt1; ++i)
	{
		cout << VT[i] << " ";
	}
	cout << endl;
	cout << "**********FIRSTVT**********" << endl;
	for (int i = 0; i < cnt; ++i)
	{
		cout << VN[i] << " : ";
		for (int j = 0; j < numF[i]; ++j)
		{
			cout << FIRSTVT[i][j] << " ";
		}
		cout << endl;
	}
	cout << "**********LASTVT**********" << endl;
	for (int i = 0; i < cnt; ++i)
	{
		cout << VN[i] << " : ";
		for (int j = 0; j < numL[i]; ++j)
		{
			cout << LASTVT[i][j] << " ";
		}
		cout << endl;
	}
}

int main()
{
	int cnt = 0;//产生式的个数,非终结符号的个数
	int cnt1 = 0;//终结符号的个数
	char** buffer;//存储txt文件的信息
	char** VN;//非终结符集合
	char** VT;//终结符集合
	char** NVT;
	char*** SET;
	char*** FIRSTVT;
	char*** LASTVT;
	production* prod;//产生式集合

	buffer = new char* [MAX];
	VN = new char* [MAX];
	VT = new char* [MAX];
	NVT = new char* [MAX];
	SET = new char** [MAX];
	FIRSTVT = new char** [MAX];
	LASTVT = new char** [MAX];
	for (int i = 0; i < MAX; ++i)
	{
		buffer[i] = new char[MAX];
		VN[i] = new char[MAX];
		VT[i] = new char[MAX];
		NVT[i] = new char[MAX];
	}
	for (int i = 0; i < MAX; ++i)
	{
		SET[i] = new char* [MAX];
		FIRSTVT[i] = new char* [MAX];
		LASTVT[i] = new char* [MAX];
		for (int j = 0; j < MAX; ++j)
		{
			SET[i][j] = new char[MAX];
			FIRSTVT[i][j] = new char[MAX];
			LASTVT[i][j] = new char[MAX];
		}
	}

	cnt = getInput(buffer);
	prod = new production[cnt];
	getProductions(buffer, prod, cnt);
	getVN(VN, prod, cnt);
	cnt1 = getVT(VT, VN, prod, cnt, SET);
	if (!check(prod, cnt, VT, cnt1))
	{
		cout << "This is not an operator-first grammar!" << endl;
        system("pause");
        exit(-1);
	}
	make_first(prod, VT, cnt, cnt1, FIRSTVT, SET);
	make_last(prod, VT, cnt, cnt1, LASTVT, SET);
	printinfo(cnt, cnt1, prod, VN, VT, FIRSTVT, LASTVT);
	make_table(prod, cnt, cnt1, SET, VT, VN, FIRSTVT, LASTVT);
	print_table(VT, cnt1);
    system("pause");
    return 0;
}